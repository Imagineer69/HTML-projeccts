#include<iostream>
using namespace std;
int main()
{
    int i=1;
    do{
        cout<<i*6<<endl;
        i++;

    } while(i<11);
    return 0;
}